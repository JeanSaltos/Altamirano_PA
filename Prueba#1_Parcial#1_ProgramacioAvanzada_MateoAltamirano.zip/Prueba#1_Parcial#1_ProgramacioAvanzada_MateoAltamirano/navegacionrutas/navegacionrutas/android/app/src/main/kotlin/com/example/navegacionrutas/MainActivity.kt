package com.example.navegacionrutas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
